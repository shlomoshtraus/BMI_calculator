import javax.swing.*;
import java.awt.*;
import java.util.stream.IntStream;

public class MainPanel extends Panel {

    private final JFrame frame = new JFrame("main");
    private JPanel mainPanel, detailsPanel, centerPanel, titlePanel, resultPanel, rightPanel;
    private final JLabel titleText = new JLabel ("BMI calculator");
    JButton sum = new JButton("Sum");
    private final Color color = new Color(204, 157, 96);
    private final Color color2 = new Color(97, 119, 135);
    private final Dimension mainDimension = new Dimension(640,540);
    private final Dimension detailsPanelDimension  = new Dimension(110,340);
    private final Dimension rightPanelDimension  = new Dimension(80,340);
    private final Dimension centerPanelDimension  = new Dimension(430,380);
    private final Dimension titlePanelDimension  = new Dimension(640,60);
    private final Dimension resultPanelDimension  = new Dimension(640,100);
    private final Font textFont1 = new Font("Arial", Font.BOLD,20);
    private final Font textFont2 = new Font("Arial", Font.BOLD,40);
    private final Font textFont3 = new Font("Arial", Font.BOLD,15);

    MainPanel(){

        initTitlePanel();
        initDetailsPanel();
        initRightPanel();
        initCenterPanel();
        initResultPanel();
        initMainPanel();
        initFrame();

    }


    private void initResultPanel(){
        resultPanel = new JPanel();
        resultPanel.setPreferredSize(resultPanelDimension);
        resultPanel.setLayout(null);
        resultPanel.setBackground(color);

    }

    private void initRightPanel(){
        rightPanel = new JPanel();
        rightPanel.setPreferredSize(rightPanelDimension);
        rightPanel.setLayout(null);
        rightPanel.setBackground(color);
    }

    private void initTitlePanel(){
        titlePanel = new JPanel();
        titlePanel.setPreferredSize(titlePanelDimension);
        titlePanel.setBackground(color);
        titlePanel.add(titleText);
        titleText.setFont(textFont2);
    }

    private void initDetailsPanel(){
        detailsPanel = new JPanel();
        JLabel name = new JLabel("Name");
        JLabel lastName = new JLabel("Last Name");
        JLabel age = new JLabel("Age");
        JTextField nameBox = new JTextField();
        JTextField lastNameBox = new JTextField();
        JComboBox ageBox = new JComboBox(setComboBox());

        name.setFont(textFont1);
        lastName.setFont(textFont1);
        age.setFont(textFont1);
        nameBox.setFont(textFont3);
        lastNameBox.setFont(textFont3);
        ageBox.setFont(textFont3);

        name.setBounds(25,30,90,25);
        nameBox.setBounds(10,60,90,25);
        lastName.setBounds(5,115,110,25);
        lastNameBox.setBounds(10,145,90,25);
        age.setBounds(35,190,90,25);
        ageBox.setBounds(25,220,60,25);

        detailsPanel.setPreferredSize(detailsPanelDimension);
        detailsPanel.setBackground(color);
        detailsPanel.setLayout(null);
        detailsPanel.add(name);
        detailsPanel.add(nameBox);
        detailsPanel.add(lastName);
        detailsPanel.add(lastNameBox);
        detailsPanel.add(age);
        detailsPanel.add(ageBox);
    }

    private void initCenterPanel(){

        centerPanel = new JPanel();
        JSlider slider =new JSlider(140,190,140);
        JLabel gender = new JLabel("Gender:");
        JLabel bodyFrame = new JLabel("Body-frame:");
        JLabel sliderLabel = new JLabel(""+ slider.getValue());
        JLabel height = new JLabel("Height:");
        JLabel actualWeight = new JLabel("Actual weight:");
        JRadioButton male = new JRadioButton("male");
        JRadioButton female = new JRadioButton("female");
        JRadioButton other = new JRadioButton("other");
        JRadioButton small  = new JRadioButton("small");
        JRadioButton medium = new JRadioButton("medium");
        JRadioButton large= new JRadioButton("large");
        ButtonGroup genderGroup = new ButtonGroup();
        ButtonGroup bodyFrameGroup = new ButtonGroup();
        JTextField actualWeightBox = new JTextField();

        actualWeight.setFont(textFont1);
        actualWeight.setBounds(285,20,140,25);
        actualWeightBox.setBounds(315,55,70,25);


        height.setBounds(185,135,90,25);
        height.setFont(textFont1);
        slider.setBounds(50,175,330,45);
        slider.setPaintTicks(true);
        slider.setBackground(color2);
        slider.setMinorTickSpacing(1);
        slider.setMajorTickSpacing(10);
        slider.setPaintLabels(true);
        slider.setFont(new Font("Arial",Font.PLAIN,15));
        sliderLabel.setBounds(180,225,50,22);
        sliderLabel.setFont(new Font("Arial",Font.PLAIN,20));
        slider.addChangeListener(e -> sliderLabel.setText(""+ slider.getValue()));

        genderGroup.add(male);
        genderGroup.add(female);
        genderGroup.add(other);
        bodyFrameGroup.add(small);
        bodyFrameGroup.add(medium);
        bodyFrameGroup.add(large);

        gender.setFont(textFont1);
        gender.setBounds(30,20,100,18);
        male.setBounds(35,45,100,20);
        female.setBounds(35,70,100,20);
        other.setBounds(35,95,100,20);
        male.setBackground(color2);
        female.setBackground(color2);
        other.setBackground(color2);
        male.setFont(textFont3);
        female.setFont(textFont3);
        other.setFont(textFont3);

        bodyFrame.setFont(textFont1);
        bodyFrame.setBounds(145,20,150,25);
        small.setBounds(150,45,100,20);
        medium.setBounds(150,70,100,20);
        large.setBounds(150,95,100,20);
        small.setBackground(color2);
        medium.setBackground(color2);
        large.setBackground(color2);
        small.setFont(textFont3);
        medium.setFont(textFont3);
        large.setFont(textFont3);

        sum.setBounds(175,260,80,50);
        sum.setFont(textFont1);
        sum.setBackground(color);
        sum.setForeground(Color.WHITE);
        double d = 0;
        if(!actualWeightBox.getText().isEmpty()){
            d=Double.parseDouble(actualWeightBox.getText());
        }

        centerPanel.setPreferredSize(centerPanelDimension);
        centerPanel.setBackground(color2);
        centerPanel.setLayout(null);
        centerPanel.add(gender);
        centerPanel.add(male);
        centerPanel.add(female);
        centerPanel.add(other);
        centerPanel.add(bodyFrame);
        centerPanel.add(small);
        centerPanel.add(medium);
        centerPanel.add(large);
        centerPanel.add(actualWeight);
        centerPanel.add(actualWeightBox);
        centerPanel.add(height);
        centerPanel.add(slider);
        centerPanel.add(sliderLabel);
        centerPanel.add(sum);

    }

    private void initFrame(){
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setPreferredSize(mainDimension);
        frame.setResizable(false);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.add(mainPanel);
    }

    private void initMainPanel(){
        mainPanel = new JPanel();
        mainPanel.setSize(mainDimension);
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(color);
        mainPanel.add(titlePanel,BorderLayout.NORTH);
        mainPanel.add(detailsPanel,BorderLayout.WEST);
        mainPanel.add(rightPanel,BorderLayout.EAST);
        mainPanel.add(centerPanel,BorderLayout.CENTER);
        mainPanel.add(resultPanel,BorderLayout.SOUTH);
    }

    private String[] setComboBox(){
        int[] rangeArr = IntStream.rangeClosed(1, 120).toArray();
        String[] toStringArr = new String[120];
        for (int i = 0; i < rangeArr.length; i++) {
            toStringArr[i] = Integer.toString(rangeArr[i]);
        }
        return toStringArr;
    }

    public JButton getSum(){
        return this.sum;
    }
}
