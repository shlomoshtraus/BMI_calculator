import javax.swing.*;
import static java.lang.Math.pow;

public class Controllers {

    Controllers(JButton jButton, double weight, double height){
        height = (height/100);

        double finalHeight = height;
        jButton.addActionListener(e -> System.out.println("BMI: " + weight/(pow(finalHeight,2))));
    }
}
